#include <iostream>
#ifndef USER_CPP
#define USER_CPP
//#include "User.h"
using namespace std;
class User{
    private:
            string name;
            int ratings[100];
            int numRatings;           
    public:
 // constructor with parameters
            User(string user_name, int array[], int rating){
                name = user_name;
                for(int i = 0; i < rating; i++)
                {
                    ratings[i] = array[i];
                }
                numRatings = rating;
            }
            // default constructor
            User(){
                name = "NONE";
                ratings[100] = {0};
                numRatings = 0;
            }
            int index;
            // getter and setters for name and numRatings
            string getName(){return name;}
            int getNumRatings(){return numRatings;}
            int getRatingAt(int index){
                if(index < numRatings)
                {
                    return ratings[index];
                }
                 else if(index >= numRatings)
                 {
                     return -1000;
                 }
            }
            void setName(string user_name){ name = user_name;}
            void setNumRatings(int rating){ numRatings = rating;}
            int setRatingAt(int index, int rating){
                if(index < numRatings)
                {
                    ratings[index] = rating;
                }
                else if(index >= numRatings)
                {
                    return -1000;
                }
                else if(rating >= -5 && rating <= 5)
                {
                    cout << "Success!"<<endl;
                    return 0;
                }
                else
                {
                    cout<<"Invalid Input"<<endl;
                    return -1;
                }
            }
};
// int main()
// {
//     User user1;
// }

#endif