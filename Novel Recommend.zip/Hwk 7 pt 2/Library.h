#ifndef LIBRARY_H
#define LIBRARY_H
#include <iostream>
#include <iomanip>
#include <fstream>
#include "Book.cpp"
#include "User.cpp"
using namespace std;

class Library{
    private: 
    Book book[100];
    User user[100];
    int numbooks; //number in books array
    int numUser; //number in users array
    int index; //user location
    public:
    Library(){
    }
    void Load();
    void login();
    void setUser(int Index);
    int Split(string s, char character, string array[], int max);
    void menu();
    int GetScores(string s, int array[], int maximum);
    void viewratings(); 
    void ratethebook();
    void recommendbooks();
    void quit();
    
};
    #endif