#include <iostream>
#include <iomanip>
#include <math.h> 
using namespace std;

#include <iostream>
#ifndef USER_CPP
#define USER_CPP
using namespace std;
class User{
    private:
            string name;
            int ratings[100];
            int numRatings;           
    public:
 // constructor with parameters
            User(string user_name, int array[], int rating){
                name = user_name;
                for(int i = 0; i < rating; i++)
                {
                    ratings[i] = array[i];
                }
                numRatings = rating;
            }
            // default constructor
            User(){
                name = "NONE";
                ratings[100] = {0};
                numRatings = 0;
            }
            //int index;
            // getter and setters for name and numRatings
            string getName(){return name;}
            int getNumRatings(){return numRatings;}
            int getRatingAt(int index){
                if(index < numRatings)
                {
                    return ratings[index];
                }
                 else if(index >= numRatings)
                 {
                     return -1000;
                 }
            }
            void setName(string user_name){ name = user_name;}
            void setNumRatings(int rating){ numRatings = rating;}
            int setRatingAt(int index, int rating){
                if(index < numRatings)
                {
                    ratings[index] = rating;
                }
                else if(index >= numRatings)
                {
                    return -1000;
                }
                else if(rating >= -5 && rating <= 5)
                {
                    cout << "Success!"<<endl;
                    return 0;
                }
                else
                {
                    cout<<"Invalid Input"<<endl;
                    return -1;
                }
            }
};
#endif
	
#include <iostream>
#ifndef BOOK_CPP
#define BOOK_CPP
using namespace std;
class Book {
  private:
    string title; //data members
    string author;
  public:
    //constructor
Book(string AUTHOR, string TITLE){
        title = TITLE;
        author = AUTHOR;
    } //default constructor
Book(){
        title = "NONE";
        author = "NONE";
    }
    string getTitle(){return title;} //member functions
    string getAuthor(){return author;}
    
    void setTitle(string TITLE){ title = TITLE;}
    void setAuthor(string AUTHOR){ author = AUTHOR;}
};
#endif

#ifndef LIBRARY_H
#define LIBRARY_H
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
class Library{
 private: 
    Book book[100];
    User user[100];
    int numbooks; //number in books array
    int numUser; //number in users array
    int index; //user location
 public:
    Library(){
    }
    int Split(string s, char character, string array[], int max) //split words function
    {
        if(s.length() == 0) //if nothing in string return 0 
    {
        return 0;
    }
        string word = ""; //set string variable empty
        int j = 0; //initialize variable to count delimiter
        for(int e = 0; e < s.length(); e++) //for-loop split function
        {
            if(s[e] != character) //if index not equal to delimiter save index character in word variable
            {
                word = word + s[e];
            }
            else if(s[e] == character) //if index equal to delimiter save word to array at index j and empty word 
            {
                array[j] = word;
                word = "";
                j++;
            }
        } 
        array[j] = word; //fill last word in array
        return j+1; //return delimiter count + 1 for word amount
    }
    
    
    int GetScores(string s, int a[], int maximum) //split integers function
    {
    int j = 0;
    string number[100]; //set integer array
    char delimiter = ' '; //space character is the delimiter 
    for(int e = 0; e < 55; e++){
       a[e] = {0};
    }
    int count = Split(s, delimiter, number, maximum); //call the split function and set to variable to return value
    for(int i = 0; i < count; i++) //for-loop to fill integer array with substrings converted to integers 
    {
        if(number[i] != ""){
            a[j] = stoi(number[i]);
            j++;
        }
    }
        return count; //return number of integers out of string
    }
    
    //Load ratings and book
    void Load()
    {
        ifstream books;
        ifstream ratings;
        books.open("books.txt");
        ratings.open("ratings.txt");
        string line = "";
        string line2 = "";
        int Indexone = 0;
        int Index = 0;
        numbooks = 0;
        numUser = 0;
        int numratings = 0;
        int booknumber = 55;
        string tempratings = "";
        int numbers[55];
        int ratearr[100] = {0};
        int k = 0;
   
        if(books.is_open()&&ratings.is_open())
        {
    	   while(!books.eof())
    	   {
    		 getline(books, line, '\n'); //book title and author
    		 if(line.length() > 0)
    		 {
    			int j = 0;//Lowercase book title and author
    	        while(j < line.length())
    	        {
				    line[j] = tolower(line[j]);
				    j++;
			    }
				char delimiter = ',';
				int n = 100;
				string b_array[100] ={""};
				int count = Split(line, delimiter, b_array, n);
				line = "";
				string author = b_array[0]; //fill book and author
				string title = b_array[1]; 
				string Titl = "";
		        for(int k = 0; k < title.length()-1;k++){ //remove space character at end
		            if(title[k] != '\n'){
		                Titl = Titl + title[k];
		            }
		        }
				Book b(author, Titl); //book object
				
				book[Indexone] = b; //fill book[] array with object
	            
	            numbooks = numbooks + (count-1); //count number in book[] array
    		 }
    		 Indexone++;
    	   }
	       while(!ratings.eof()){
	           getline(ratings, line2); //ratings array
	       if(line2.length() > 0){
			    string aarray[100]={""};
			    char delimiter = ',';
				int n = 100;
				int counts = Split(line2, delimiter, aarray, n); //call split
				line2 = "";
				string name = aarray[0]; //fill user
			
				tempratings = aarray[1]; //fill ratings in temp string
                for(int e = 0; e < 55; e++){
                    numbers[e] = {0};
                }
                int l_count = GetScores(tempratings, numbers, 55); //call the split function and set to variable to return value
                tempratings = "";
                
                user[Index].setNumRatings(booknumber);
                for(int r = 0; r < 55; r++){
                     user[Index].setRatingAt(r,numbers[r]);
                }
				User a(name, numbers, booknumber); //user object
			    user[Index] = a; //fill user[] with each user 
			    numUser = numUser + (counts-1); 
	            }
	            Index++;
			}
    	} 
    	  else 
        {
            cout << "Launch unsuccessful" << endl;
            cout << "Error! books or ratings file could not be found." << endl;
            exit;
        }
    }
    
    void setUser(int Index){
      index = Index;
  }
    
  void login(){
           string line3;
    	   cout << "Data Loaded successfully!" <<endl;
    	   cout <<"Welcome to the Library, What is your name?: "<<endl;
    	   getline(cin, line3);
		   
		   //Lowercase(line3);
		   string lineP = line3;
		   int K = 0;
    	   while(K < line3.length())
    	   {
				lineP[K] = tolower(line3[K]);
				K++;
			}
    	   while(lineP.length() == 0)
    	   {
    	       string linetemp;
    	       cout << "You provided an empty user name, Please provide a valid user name to login or register: " << endl;
    	       cout << "Enter your name again: " << endl;
    	       getline(cin, linetemp);
    	       if(linetemp.length() != 0)
    	       {
    	       	   //Lowercase(linetemp);
    	       	   int K = 0;
    			   while(K < linetemp.length())
    			   {
					linetemp[K] = tolower(linetemp[K]);
					K++;
				    }
    	       	   
    	           lineP = linetemp;
    	           break;
    	       }
    	   }
    	   
    	   for(int i = 0;i < numUser;i++)
    	   {
    	       if(user[i].getName() == lineP)
    	       {
    	          cout<< "Welcome back, " << line3 << endl;
    	          setUser(i);
    	          break;
    	       }
    	   }
    	   
    	   if(lineP != user[index].getName()) //add unknown user
    		{
    		    numUser++;
    	    	user[numUser].setName(lineP);
    	    	setUser(numUser);
    	    	user[numUser].setNumRatings(55);
    	    	for(int u = 0; u<55; u++){
    	    	    user[numUser].setRatingAt(u, 0);
    	    	}
    	    	 cout<< "Welcome to the Library, " << line3 << endl;
    		}
  }
  
    
  //view ratings function
  void  viewratings()
    {
        if(index < numUser){
    	    cout<< "Here are the books that you have rated: " << endl;
    	    for(int i = 0;i < numbooks; i++){
    		    if(user[index].getRatingAt(i) != 0 && user[index].getRatingAt(i) != -1000){
    			    cout << "Title : " << book[i].getTitle() << endl;
    			    cout << "Rating : " << user[index].getRatingAt(i) << endl;
    			    cout << "------------------------------"<< endl;
    		    }
    	    }
    	}
    	else{
    	    cout<<"You have not rated any books as yet:"<<endl;
    	}
    	menu();
    }
    // rate books function
    void  ratethebook(){
        int ind = 0; 
        int rate = 0;
        string linee = "";
        cout << "Enter the name of the book that you would like to rate: " << endl;
        getline(cin,linee,'\n');
        
        int j = 0;
        while(j < linee.length())
    	{
			linee[j] = tolower(linee[j]);
			j++;
    	}
    	
		if(linee.length() > 0){
            cout<<"Enter your rating of the book: " << endl;
            cin >> rate;
            if(rate == -5||rate == -3||rate ==0||rate == 1||rate == 3||rate == 5){
                for(int i = 0; i < 56; i++){
                 if(linee == book[i].getTitle()){
                    ind = i;
                    break;
                    }
                }
            cin.ignore();
            while(linee.length() == 0 || linee != book[ind].getTitle()){
                string temp2 = "";
                cout << "The book requested does not exist in the database" <<endl;
                cout << "Enter the name of the book that you would like to rate: " << endl;
                getline(cin,temp2);
                int j = 0;
                while(j < temp2.length())
    	        {
			        temp2[j] = tolower(temp2[j]);
			        j++;
    	        }
                for(int i = 0; i < 55; i++){
                    if(temp2 == book[i].getTitle()){
                        linee = temp2;
                        ind = i;
                        break;
                    }
                }
            } //rating must be on table to rate book
            if(linee == book[ind].getTitle()&&(rate == -5||rate == -3||rate ==0||rate == 1||rate == 3||rate==5)){ 
              user[index].setRatingAt(ind, rate); //set rating
              cout << "Success!" << endl; //print statement
              cout << "Thank-you. The rating for the book titled" << " \"" << book[ind].getTitle() << "\"" <<" has been updated to "<< rate << endl; //print statement
            }  
            
        }
	}
	    cin.clear();
        menu();
    }
    
    // recommend books function
    void  recommendbooks(){

        //find most similar user
        int urate = 0;
        int other = 0;
        double scores[87]={0.0};
        double score = 0.0;
        int mvalue = 0;
        int bestother = 0;
        for(int i = 0; i < 100;i++){
            urate = user[index].getRatingAt(i);
            for(int k = 0; k< 87;k++){
                other = user[k].getRatingAt(i);
                if(k != index){
                    score = pow((urate - other),(2));
                }
                scores[k] = score; 
            }
        } // find other user index
        mvalue = scores[0];
        for(int e = 0; e < 87; e++){
            if(scores[e]<mvalue){
                mvalue = scores[e];
                bestother = e;
            }
        } 
        int nbooks = 0;
        if(index < numUser){
        for(int w = 0; w <55; w++){
            int g =user[bestother].getRatingAt(w);
            int h = user[index].getRatingAt(w);
            if((g == 3 || g == 5) && h == 0 && nbooks < 10){
                if(w == 0){
                    cout << "Here are some of the books that we think you would like" << endl;
                }
                cout << book[w].getTitle() << " by " << book[w].getAuthor() << endl;
                nbooks++;
            }
        }
        }
        if(nbooks == 0){
                cout << "There are no recommendations for you at present" << endl;
            }
        menu();
    }
    
    
   // quit and save function
   void quit(){
       int nrate[100];
       string name;

       fstream rate_new;
       rate_new.open("ratings.txt");
       if(rate_new.is_open())
       {
           int i = 0;
           while(! rate_new.eof()&& i< numUser){
               name = user[i].getName();
               rate_new << name<< ",";
               for(int k = 0; k<55; k++){
                rate_new <<" "<< user[i].getRatingAt(k); 
               }
               rate_new << endl;
               i++;
           }
       }
       cout << "Data successfully saved. Goodbye!" << endl;
   }
   
   
   //menu options function
   void menu(){
    string choice;
    cout << "Would you like to (v)iew your ratings, (r)ate a book, (g)et recommendations, or (q)uit?: " << endl;
	getline(cin, choice, '\n');
	
	int j = 0; //Lowercase choice
    while(j < choice.length())
    {
		choice[j] = tolower(choice[j]);
		j++;
	}
	while(!(choice == "v" ||choice == "r" ||choice == "g" ||choice == "q")){
		string choice2;
		cout << "Please input a valid choice" << endl;
		cout << "Would you like to (v)iew your ratings, (r)ate a book, (g)et recommendations, or (q)uit?: " << endl;
		cin >> choice2;
		if(choice2 == "v" ||choice2 == "r" ||choice2 == "g" ||choice2 == "q"){
			choice = choice2;
			break;
		}
	}
	if(choice != "q"){
		if(choice == "v"){
			viewratings();
		}
		else if(choice == "r"){
		    ratethebook();
		}
		else if(choice == "g"){
		    recommendbooks();
		}
	}
	else{
	    quit();
	}
	
   }
};  
#endif	

int main()
{
	Library library;
    library.Load();
    library.login();
    library.menu();
}
