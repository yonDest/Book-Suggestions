#include <iostream>
#ifndef BOOK_CPP
#define BOOK_CPP
//#include "Book.h"
using namespace std;
//Yonathan Desta 
//Recitation TA: Harishini Muthukrishnan
//Homework 7 pt.1 #1

/*  *Algorithm:
    *1. Start
     2. Read Author and book title  
     3. Include set Author and book title function
     4. Include get Author and book title function
    *input: Author and book title
    *output: Author and book title
    *returns: nothing

*/
class Book {
  private:
    string title; //data members
    string author;
  public:
    //constructor
Book(string AUTHOR, string TITLE){
        title = TITLE;
        author = AUTHOR;
    } //default constructor
Book(){
        title = "NONE";
        author = "NONE";
    }
    string getTitle(){return title;} //member functions
    string getAuthor(){return author;}
    
    void setTitle(string TITLE){ title = TITLE;}
    void setAuthor(string AUTHOR){ author = AUTHOR;}
};

// int main(){
//   Book book7; //test case 1 for book class
//   book7.setTitle("MYBOOK"); //call to set function
//   book7.setAuthor("John Adams");
//   cout << book7.getTitle() << endl; //call to get function
//   cout << book7.getAuthor() << endl;
//   cout << " "<< endl;
//   Book book; //test case 2 for book class
//   book.setTitle("HARRY POTTER"); //call to set function
//   book.setAuthor("JK Rowling");
//   cout << book.getTitle() << endl; //call to get function
//   cout << book.getAuthor() << endl;
// }

#endif